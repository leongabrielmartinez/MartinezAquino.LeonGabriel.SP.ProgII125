
package modelo;

import java.io.Serializable;

public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, CSVSerializable{
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private int capacidadTripulacion;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre, int capacidadTripulacion, Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

  

    @Override
    public int compareTo(NaveEspacial N2) {
        return nombre.compareTo(N2.nombre);
    }

    @Override
    public String toString() {
        return "id = " + id + ", nombre = " + nombre + ", capacidadTripulacion = " + capacidadTripulacion + ", categoria = " + categoria;
    }

    public String toCSV(){
        return id + "," + nombre + "," + capacidadTripulacion + "," + categoria;
    }
    
    public static NaveEspacial fromCSV(String empleadoCSV){
            String[] values = empleadoCSV.split(",");
            NaveEspacial toReturn = null;
                       
            if(values.length == 4){
                int id = Integer.parseInt(values[0]);
                String nombre = values[1];
                int capacidadTripulacion = Integer.parseInt(values[2]);
                Categoria categoria = Categoria.valueOf(values[3]);
                toReturn = new NaveEspacial(id, nombre, capacidadTripulacion, categoria);
        }
        return toReturn;
    }        

    @Override
    public void guardarComoCSV() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public void leerComoCSV() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    
}
