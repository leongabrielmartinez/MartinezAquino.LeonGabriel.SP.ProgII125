
package modelo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicio.NaveService;
import servicio.Serializador;

public class Inventario<T> {
    private List<T> datos = new ArrayList<>();
    

    public void agregar(T item) {
        if (item == null){
            throw new IllegalArgumentException();
        }
        datos.add(item);
    }

    private boolean validarIndice(int indice){
        Boolean toReturn = true;
        if(indice < 0 || indice >= datos.size()){
            toReturn = false;
        }
          return toReturn;
    }

    public T obtener(int indice) {
        if(!validarIndice(indice)){
            throw new IndexOutOfBoundsException();
        }
        return datos.get(indice);
    }


    public void eliminar(int indice) {
        if(!validarIndice(indice)){
            throw new NoSuchElementException("El elemento no se encuentra en la lista.");
        }
        datos.remove(indice);
    }
    
    public <T> void listarElementos(){
        for(Object e: datos){
            System.out.println(e);
        }
    }
    
    public void ordenarElementos(){
        datos.sort((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void ordenarElementos(Comparator<? super T> comparator){
        datos.sort(comparator);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T item : datos) {
            if(criterio.test(item)){
                aux.add(item);
            }           
        }       
        return aux;
    }
    
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> auxReturn = new ArrayList<>(); 
        for (T item : datos) {
            auxReturn.add(transformacion.apply(item));
            }     
        return auxReturn;
    }
    
    public void guardarComoCSV(String path){
        NaveService.guardarNavesEspacialesCSV((List<? extends NaveEspacial>) datos, path);
    }
    public void cargarDesdeCSV(String path){
        NaveService.cargarNavesEspacialesCSV(path);
    }
    public void serializar(String path){
        Serializador.serializarLista((List<? extends NaveEspacial>) datos, path);
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        for(T item : datos){
            accion.accept(item);
        }
    }
}
