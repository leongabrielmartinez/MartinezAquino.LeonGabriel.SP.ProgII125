
package modelo;

public interface CSVSerializable {
    void guardarComoCSV();
    void leerComoCSV();
}
