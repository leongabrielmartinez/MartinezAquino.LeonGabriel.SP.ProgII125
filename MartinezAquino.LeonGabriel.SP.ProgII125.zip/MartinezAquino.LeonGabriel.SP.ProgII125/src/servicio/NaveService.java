
package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import modelo.NaveEspacial;

public class NaveService {    
    
    public static void guardarNavesEspacialesCSV(List<? extends NaveEspacial> lista, String path){
        File archivo = new File(path);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            
            bw.write("nombre,capacidadtripulacion,categoria\n");
            for(NaveEspacial e: lista){                
                bw.write(e.toCSV() + "\n");
            }
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static List<NaveEspacial> cargarNavesEspacialesCSV(String path){
    List<NaveEspacial> toReturn = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(path))){
        String linea;
        br.readLine();
        while ((linea = br.readLine()) != null){    
            if(linea.endsWith(("\n"))){
                linea = linea.substring(linea.length() - 1);                
            }            
                toReturn.add(NaveEspacial.fromCSV(linea));            
        }
    } catch (IOException ex){
        System.out.println(ex.getMessage());
    }
    return toReturn;
    }  
}
